<!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; BILI SHOP PONTIANAK</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer --><?php /**PATH C:\BELAJAR-LARAVELL\resources\views/layout/footer.blade.php ENDPATH**/ ?>