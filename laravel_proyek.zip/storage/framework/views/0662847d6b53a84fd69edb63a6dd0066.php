<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\BELAJAR-LARAVELL\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>