<!-- Component Tabel Kategori Dashboard (Read Only / Non-CRUD) -->
<div class="card shadow mb-4">
    <div class="card-header py-3 bg-success text-white">
        <h6 class="m-0 font-weight-bold">
            <i class="fas fa-tags mr-2"></i>Tabel Data Kategori
            <span class="badge badge-light text-success ml-2"><?php echo e(count($kategori)); ?> data</span>
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle" width="100%" cellspacing="0">
                <thead class="thead-light">
                    <tr>
                        <th class="text-center align-middle" style="width: 50px;">No</th>
                        <th class="align-middle" style="width: 250px;">Nama Kategori</th>
                        <th class="align-middle">Deskripsi</th>
                        <th class="text-center align-middle" style="width: 160px;">Jumlah Produk</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center align-middle"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle font-weight-bold text-dark">
                            <?php echo e($kat->nama_kategori); ?>

                        </td>
                        <td class="align-middle text-muted"><?php echo e($kat->deskripsi ?? '-'); ?></td>
                        <td class="text-center align-middle">
                            <span class="badge badge-pill badge-primary px-3 py-1 font-weight-bold">
                                <?php echo e($kat->produks_count ?? 0); ?> Produk
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-4 text-muted">
                            <i class="fas fa-folder-open fa-2x mb-2 text-gray-300 d-block"></i>
                            Belum ada data kategori<?php echo e(!empty($search) ? ' yang sesuai pencarian' : ''); ?>.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\BELAJAR-LARAVELL\resources\views/dashboard/kategori.blade.php ENDPATH**/ ?>